 <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-12 footer-contact" data-aos="fade-up" data-aos-delay="100">
            <h3>OSIS SMKN 5 Bandung</h3>
            <p>
             Jl. Bojong Koneng No.37A, Sukapada, Kec. Cibeunying Kidul <br>
             Kota Bandung<br>
              Jawa Barat 40191<br><br>
              <strong>Phone:</strong> 089668057456<br>
              <strong>Email:</strong> infoosissmkn5bandung@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-3 col-md-6 footer-links" data-aos="fade-up" data-aos-delay="300">
            <h4>Tentang</h4>
            <ul>
              <li><a href="{{route('home')}}#tentang_kami">Tentang Kami</a></li>
              <li><a href="{{route('home')}}#sekbid">Seksi Bidang</a></li>
              <li><a href="{{route('home')}}#video_osis">Video OSIS</a></li>
              <li><a href="{{route('home')}}#eskul">Ekstrakulikuler</a></li>
              <li><a href="{{route('home')}}#galeri_osis">Galeri OSIS</a></li>
              <li><a href="{{route('home')}}#kata_mereka">Harapan untuk OSIS</a></li>
      
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links" data-aos="fade-up" data-aos-delay="400">
            <h4>Akun Sosial Media Kami</h4>
            <p>Jangan sampai kelewatan informasi dan kegiatan menarik kami</p>
           <div class="social-icon text-center">
              <a class="instagram" href="#"><i class="lni-instagram-filled"></i></a>
            
</div>
          </div>

        </div>
      </div>
    </div>

    <div class="container py-4">
      <div class="copyright">
        &copy;<strong><span>Seksi Bidang 9</span></strong>. OSIS SMKN 5 Bandung 2019/2020
      </div>
    </div>
  </footer>